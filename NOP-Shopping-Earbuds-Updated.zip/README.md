NOP SHOPPING — GITHUB PAGES PACKAGE

Files:
- index.html: responsive storefront entry page
- .nojekyll: tells GitHub Pages not to run Jekyll processing

PUBLISH WITH GITHUB PAGES (FREE):
1. Create a PUBLIC repository named nop-shopping on GitHub.
2. Upload index.html, .nojekyll and this README.md to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Choose branch main and folder /(root), then Save.
6. Wait for the Pages deployment to finish. Your site URL will be:
   https://YOUR-GITHUB-USERNAME.github.io/nop-shopping/

NOTES:
- GitHub Free requires a public repository for GitHub Pages. Published pages are public.
- This is a static storefront; it does not process payments or manage inventory.
- Confirm supplier stock, final price, shipping and delivery terms before accepting direct orders.
- Existing affiliate and WhatsApp links are retained.
